# Methods — RNA-seq Quality Control & Data Generation

> **使用说明**：以下文字可直接复制到 thesis 的 Methods 章节。方括号 `[ ]` 中的内容需要你根据实际情况补充。

---

## 完整 Methods 段落（中文版）

### RNA 提取与质量评估

总 RNA 自胚胎第 18 天（E18）大鼠（*Rattus norvegicus*）皮层神经元中提取。本研究包含两组实验，每组各 3 个生物学重复（biological replicates），来自独立的细胞培养批次：

**Group A（24 小时处理实验）**包含三个实验组：**DIV1**（细胞培养第 1 天，起始时间点）、**DIV2**（DIV1 后经 24 h vehicle 处理的对照组）和 **DIV2 + Netrin-1**（DIV1 后经 24 h 重组小鼠 Netrin-1 [终浓度] 处理）。

**Group B（急性刺激时间序列）**包含三个时间点：**0 min**（未处理对照）、**5 min** 和 **15 min**（DIV2 神经元用 Netrin-1 [终浓度] 处理后分别在指定时间收集）。

两组实验共 18 个样本。RNA 完整性（RNA integrity number, RIN）使用 Agilent Bioanalyzer 评估；所有样本 RIN ≥ 9（其中 17/18 样本 RIN = 10），样本总 RNA 量介于 1.72–2.14 µg 之间。

### 文库构建与测序

使用 [建库试剂盒名称] 构建链特异性 polyA 富集 mRNA 文库。文库在 [Illumina 测序平台型号，例如 NovaSeq 6000] 上进行双端测序，读长 2 × 101 bp。每个样本获得 34.2–53.6 百万对读段（mean: 47.7 M read pairs），平均 GC 含量 49.5–50.0%，duplication rate 介于 58.6–63.2% 之间，与哺乳动物 polyA 富集文库的预期范围一致。

### 数据处理与基因水平定量

原始测序数据由 [测序公司名称] 使用 Illumina DRAGEN RNA pipeline（v[版本号]）处理。DRAGEN 自动完成读段过滤、与 *Rattus norvegicus* rn7 参考基因组（Ensembl release [版本号]）的比对，并使用内置 Salmon 算法进行基因水平定量。每个样本最终获得 22.95–36.11 百万 quantified reads（mean: 32.3 M），共检测到 16,451–17,093 个表达基因（每个样本至少有一条 read 比对）。所有 18 个样本均通过下游分析的质量要求（详见 Supplementary Table S1, Supplementary Figure S1）。

---

## 完整 Methods 段落（英文版）

### RNA Extraction and Quality Assessment

Total RNA was extracted from embryonic day 18 (E18) rat (*Rattus norvegicus*) cortical neurons. The study comprised two independent experiments, each with three biological replicates from separate culture batches:

**Group A (24-hour treatment)** included three experimental groups: **DIV1** (day 1 *in vitro*, baseline), **DIV2** (day 2 *in vitro*, 24 h vehicle control), and **DIV2 + Netrin-1** (day 2 *in vitro*, 24 h treatment with recombinant Netrin-1 [final concentration]).

**Group B (acute time course)** included three time points: **0 min** (untreated baseline), **5 min**, and **15 min** following Netrin-1 [final concentration] stimulation of DIV2 cortical neurons.

A total of 18 samples were collected across both experiments. RNA integrity was assessed using an Agilent Bioanalyzer; all samples showed RIN ≥ 9 (17 of 18 samples with RIN = 10), and total RNA yields ranged from 1.72 to 2.14 µg.

### Library Preparation and Sequencing

Stranded polyA-enriched mRNA libraries were prepared using [library prep kit name] following the manufacturer's protocol. Libraries were sequenced on an [Illumina platform, e.g., NovaSeq 6000] platform with 2 × 101 bp paired-end reads. Each sample yielded between 34.2 and 53.6 million read pairs (mean: 47.7 M), with average GC content of 49.5–50.0% and duplication rates ranging from 58.6 to 63.2%, consistent with expectations for mammalian polyA-enriched libraries.

### Data Processing and Gene-Level Quantification

Raw sequencing data were processed by [sequencing provider] using the Illumina DRAGEN RNA pipeline (v[version]). DRAGEN performed read filtering, alignment to the *Rattus norvegicus* rn7 reference genome (Ensembl release [version]), and gene-level quantification using its integrated Salmon implementation. After quantification, 22.95–36.11 million reads (mean: 32.3 M) were assigned to genes per sample, and 16,451–17,093 expressed genes (defined as having at least one read assigned) were detected per sample. All 18 samples met quality thresholds for downstream analysis (see Supplementary Table S1 and Supplementary Figure S1).

---

## 关键数字摘要（用于 thesis 正文引用）

| 指标 | Group A 范围 | Group B 范围 | 总体 |
|------|------------|------------|------|
| Biological replicates | n = 3 per group | n = 3 per group | n = 18 total |
| RIN | 9–10 | 10 | 9–10 |
| 总 RNA 量 (ng) | 1,717–2,061 | 1,822–2,137 | 1,717–2,137 |
| Total read pairs (M) | 34.2–52.3 | 41.0–53.6 | 34.2–53.6 |
| Duplication (%) | 58.6–63.2 | 61.7–63.1 | 58.6–63.2 |
| GC content (%) | 49.5 | 49.5–50.0 | 49.5–50.0 |
| Quantified reads (M) | 22.95–35.39 | 28.05–36.11 | 22.95–36.11 |
| Detected genes | 16,451–17,012 | 16,701–17,093 | 16,451–17,093 |

**通用参数**
- Read length: 2 × 101 bp paired-end
- Library: Stranded polyA-enriched
- Reference: Rat rn7 (Ensembl)
- Quantification: DRAGEN integrated Salmon (gene-level)

---

## 项目配色（PROJECT PALETTE — FINAL · 用于所有图表）

### Group A (categorical)
| Group | Color | Hex |
|-------|-------|-----|
| **DIV1** | Light warm gray | `#9CA5A6` |
| **DIV2** | Deeper blue | `#3D6B8C` |
| **DIV2 + Netrin-1** | Warm orange | `#D97B43` |

### Group B (sequential — time)
| Time | Color | Hex |
|------|-------|-----|
| **0 min** | Pale sage | `#D6DFCE` |
| **5 min** | Medium sage | `#88A878` |
| **15 min** | Deep forest | `#3F5C36` |

---

## 需要你补充的信息（方括号项目）

1. **测序公司名称**
2. **Illumina 测序平台型号**（NovaSeq 6000, NextSeq 2000, NovaSeq X 等）
3. **建库试剂盒**（Illumina TruSeq Stranded mRNA, NEBNext Ultra II Directional 等）
4. **DRAGEN 版本号**（如 v4.2.4）
5. **Ensembl 注释版本**（如 release 110）
6. **Netrin-1 终浓度**（实验记录中的处理浓度）
7. **Vehicle / control 的具体成分**（PBS / 0.1% BSA in PBS 等）

---

## 引用建议

- **DRAGEN**: Goyal A, et al. (2017) *Ultra-fast next generation human genome sequencing data processing using DRAGEN bio-IT processor for precision medicine*. Open J Genet 7:9–19.
- **Salmon**: Patro R, Duggal G, Love MI, Irizarry RA, Kingsford C. (2017) *Salmon provides fast and bias-aware quantification of transcript expression*. Nat Methods 14:417–419.
- **DESeq2**（后续分析）: Love MI, Huber W, Anders S. (2014) *Moderated estimation of fold change and dispersion for RNA-seq data with DESeq2*. Genome Biol 15:550.

---

*Generated for thesis preparation. Edit placeholders [ ] with project-specific information before submission.*
